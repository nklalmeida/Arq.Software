﻿namespace DomainTests;

public class Class1
{

}
