using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NUnit.Framework;

namespace DomainTests.Bookings
{
    public class StateMachineTests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        public void Test1()
        {
            Assert.Pass();
        }

        [Test]
        public void Test1()
        public void Test1()
        {
            Assert.Pass();
        }

        [Test]
        public void Test1()
        public void Test1()
        {
            Assert.Pass();
        }

        [Test]
        public void Test1()
        public void Test1()
        {
            Assert.Pass();
        }

        [Test]
        public void Test1()
        public void Test1()
        {
            Assert.Pass();
        }

        [Test]
        public void Test1()
        public void Test1()
        {
            Assert.Pass();
        }
    }
}