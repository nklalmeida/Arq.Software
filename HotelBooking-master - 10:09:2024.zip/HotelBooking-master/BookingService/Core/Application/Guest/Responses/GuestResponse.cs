﻿namespace Application.Responses
{
    public class GuestResponse
    {
    }
}
