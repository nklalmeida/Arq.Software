﻿namespace Application.Ports
{
    public interface IGuestManager
    {
    }
}
