﻿namespace Application.Dtos
{
    public class GuestDto
    {
    }
}
