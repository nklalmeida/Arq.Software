﻿namespace Application.Ports
{
    public class IRoomManager
    {
    }
}
