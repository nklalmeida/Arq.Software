﻿namespace Application.Room.Responses
{
    public class RoomResponse
    {
    }
}
