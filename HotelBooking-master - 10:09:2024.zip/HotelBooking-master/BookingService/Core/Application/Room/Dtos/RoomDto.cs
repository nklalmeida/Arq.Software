﻿namespace Application.Dtos
{
    public class RoomDto
    {
    }
}
