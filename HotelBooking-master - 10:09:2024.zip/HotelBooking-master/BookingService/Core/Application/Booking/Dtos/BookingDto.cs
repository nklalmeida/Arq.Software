﻿
namespace Application.Dtos
{
    public class BookingDto
    {
    }
}
