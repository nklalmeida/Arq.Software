﻿namespace Application.Ports
{
    internal interface IBookingManager
    {
    }
}
