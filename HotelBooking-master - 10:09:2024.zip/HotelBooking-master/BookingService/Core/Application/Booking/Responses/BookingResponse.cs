﻿namespace Application.Responses
{
    public class BookingResponse
    {
    }
}
