﻿namespace Application.Responses
{
    public class PaymentResponse
    {
    }
}
