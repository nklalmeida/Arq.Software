﻿namespace Application.Ports
{
    public interface IPaymentManager
    {
    }
}
