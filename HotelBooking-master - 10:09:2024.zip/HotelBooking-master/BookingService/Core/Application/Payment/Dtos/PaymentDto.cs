﻿namespace Application.Payment.Dtos
{
    public class PaymentDto
    {
    }
}
