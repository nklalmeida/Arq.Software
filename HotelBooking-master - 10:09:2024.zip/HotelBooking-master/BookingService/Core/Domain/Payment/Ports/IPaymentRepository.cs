﻿namespace Domain.Ports
{
    public interface IPaymentRepository
    {
    }
}
