﻿namespace Domain.Ports
{
    public interface IBookingRepository
    {
    }
}
