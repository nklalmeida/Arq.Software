﻿namespace Domain.Ports
{
    public interface IRoomRepository
    {
    }
}
