﻿namespace Payments.Application
{
    public class Class1
    {

    }
}
